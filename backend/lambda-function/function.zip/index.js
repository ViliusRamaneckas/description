const AWS = require('aws-sdk');
const axios = require('axios');
const OpenAI = require('openai');

// Initialize AWS SDK with default credentials
const s3 = new AWS.S3();

// Check for OpenAI API key
if (!process.env.OPENAI_API_KEY) {
    throw new Error('OPENAI_API_KEY environment variable is required');
}

// Initialize OpenAI
const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

exports.handler = async (event) => {
    try {
        console.log('Event received:', JSON.stringify(event));
        
        // Parse the incoming request
        let imageUrl, descriptionType;
        
        // Handle both direct invocation and API Gateway events
        if (typeof event === 'string') {
            const parsed = JSON.parse(event);
            imageUrl = parsed.imageUrl;
            descriptionType = parsed.descriptionType || 'detailed';
        } else {
            imageUrl = event.imageUrl;
            descriptionType = event.descriptionType || 'detailed';
        }

        console.log('Processing image:', imageUrl);
        console.log('Description type:', descriptionType);

        if (!imageUrl) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Image URL is required' })
            };
        }

        // Get the image from S3
        console.log('Downloading image from S3...');
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        console.log('Image downloaded, size:', imageResponse.data.length);
        
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');
        const base64Image = imageBuffer.toString('base64');
        console.log('Image converted to base64, length:', base64Image.length);

        // Prepare prompt based on description type
        let prompt = '';
        switch (descriptionType) {
            case 'title':
                prompt = 'Generate a concise, catchy product title for this image. Keep it under 10 words.';
                break;
            case 'brief':
                prompt = 'Provide a brief, one-paragraph description of this image. Focus on the main elements and purpose.';
                break;
            case 'detailed':
            default:
                prompt = 'Provide a detailed description of this image, including all notable features, colors, composition, and context.';
                break;
        }

        console.log('Calling OpenAI API...');
        // Call OpenAI API directly
        const response = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            messages: [
                {
                    role: "user",
                    content: [
                        { type: "text", text: prompt },
                        {
                            type: "image_url",
                            image_url: {
                                url: `data:image/jpeg;base64,${base64Image}`,
                            },
                        },
                    ],
                },
            ],
            max_tokens: descriptionType === 'title' ? 100 : 500,
        });
        console.log('OpenAI API response received');

        const description = response.choices[0]?.message?.content || 'No description generated';
        console.log('Description generated:', description);

        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify({
                description,
                imageUrl
            })
        };
    } catch (error) {
        console.error('Error details:', {
            message: error.message,
            stack: error.stack,
            code: error.code,
            response: error.response?.data
        });
        return {
            statusCode: 500,
            body: JSON.stringify({ 
                error: 'Internal server error',
                message: error.message,
                details: error.response?.data
            })
        };
    }
}; 